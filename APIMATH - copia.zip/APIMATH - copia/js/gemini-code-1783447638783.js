const PERFILES = {
    chico_4: {
        nombre: "Mateo", // Nombre temporal
        edad: 4,
        modoVisual: "concreto-manzanas",
        tiempoActivo: false,
        controlDerecha: true
    },
    niña_8: {
        nombre: "Elena", // Nombre temporal
        edad: 8,
        modoVisual: "estándar",
        tiempoActivo: true,
        modoZurdo: true // <- Esto moverá los botones a la izquierda con CSS
    },
    chico_12: {
        nombre: "Gabriel", // Nombre temporal
        edad: 12,
        modoVisual: "juvenil-gamer",
        tiempoActivo: true,
        modoAsistidoTDAH: true // <- Divide problemas complejos en partes
    }
};