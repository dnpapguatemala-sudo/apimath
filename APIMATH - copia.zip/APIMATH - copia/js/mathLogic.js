// js/mathLogic.js

const MathGameLogic = {
    generarEjercicio: function(tipo, nivel = 1) {
        let num1, num2, operador, respuestaCorrecta;

        switch (tipo) {
            case 'suma':
                num1 = Math.floor(Math.random() * (9 * nivel)) + 1;
                num2 = Math.floor(Math.random() * (9 * nivel)) + 1;
                operador = '+';
                respuestaCorrecta = num1 + num2;
                break;
            case 'resta':
                num1 = Math.floor(Math.random() * (12 * nivel)) + 5;
                num2 = Math.floor(Math.random() * num1); 
                operador = '-';
                respuestaCorrecta = num1 - num2;
                break;
            case 'multiplicacion':
                num1 = Math.floor(Math.random() * 9) + 1;
                num2 = Math.floor(Math.random() * (4 * nivel)) + 1;
                operador = '×';
                respuestaCorrecta = num1 * num2;
                break;
            case 'division':
                let cociente = Math.floor(Math.random() * 9) + 1; 
                num2 = Math.floor(Math.random() * 8) + 2;        
                num1 = cociente * num2;                          
                operador = '÷';
                respuestaCorrecta = cociente;
                break;
        }

        return {
            pregunta: { num1: num1, num2: num2, operador: operador },
            respuestaCorrecta: respuestaCorrecta
        };
    }
};