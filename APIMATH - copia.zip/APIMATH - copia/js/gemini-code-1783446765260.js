// js/mathLogic.js

const MathGameLogic = {
    // Genera un ejercicio aleatorio según el tipo de operación y nivel
    generarEjercicio: function(tipo, nivel = 1) {
        let num1, num2, pregunta, respuestaCorrecta;

        switch (tipo) {
            case 'suma':
                // Nivel 1: dígitos del 1 al 9. Nivel 2: números más grandes.
                num1 = Math.floor(Math.random() * (9 * nivel)) + 1;
                num2 = Math.floor(Math.random() * (9 * nivel)) + 1;
                pregunta = { num1: num1, num2: num2, operador: '+' };
                respuestaCorrecta = num1 + num2;
                break;

            case 'resta':
                num1 = Math.floor(Math.random() * (12 * nivel)) + 5;
                num2 = Math.floor(Math.random() * num1); // Así evitamos resultados negativos
                pregunta = { num1: num1, num2: num2, operador: '-' };
                respuestaCorrecta = num1 - num2;
                break;

            case 'multiplicacion':
                // Tablas de multiplicar según el nivel
                num1 = Math.floor(Math.random() * 9) + 1;
                num2 = Math.floor(Math.random() * (5 * nivel)) + 1; // Sube la dificultad de las tablas
                pregunta = { num1: num1, num2: num2, operador: '×' };
                respuestaCorrecta = num1 * num2;
                break;

            case 'division':
                // Truco Kumon: Multiplicamos primero para asegurar una división exacta
                let cociente = Math.floor(Math.random() * 9) + 1; // La respuesta
                num2 = Math.floor(Math.random() * 8) + 2;        // El divisor
                num1 = cociente * num2;                          // El dividendo
                
                pregunta = { num1: num1, num2: num2, operador: '÷' };
                respuestaCorrecta = cociente;
                break;

            default:
                console.error("Tipo de operación no soportada");
                return null;
        }

        return {
            pregunta: pregunta,
            respuestaCorrecta: respuestaCorrecta
        };
    }
};